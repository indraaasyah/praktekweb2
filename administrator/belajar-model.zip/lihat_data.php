<?php 

include 'view/BeritaUI.php';

$brd = new BeritaUI();

$brd->tampilBerita();

 ?>

